#!/data/data/com.termux/files/usr/bin/bash

# Your shell script content
curl -o filename.txt https://raw.githubusercontent.com/GreyTechno/sms_forwarder/main/.info
